import React from 'react';
import { Search, Sparkles, TrendingUp, ShieldCheck, Map, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import PropertyCard from '../components/PropertyCard';
import { PropertyType, ListingType, PropertyStatus } from '../types';
import { motion } from 'motion/react';

const mockProperties = [
  {
    id: '1',
    title: 'Modern Villa with Smart Features',
    description: 'A luxurious villa located in the heart of Islamabad...',
    price: 45000000,
    location: 'Sector F-7',
    city: 'Islamabad',
    type: PropertyType.HOUSE,
    bedrooms: 4,
    bathrooms: 5,
    area: 10,
    areaUnit: 'marla' as const,
    images: ['https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=800'],
    ownerId: 'u1',
    status: PropertyStatus.ACTIVE,
    listingType: ListingType.SELL,
    isAIPredicted: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: '2',
    title: 'Luxury Apartment in Bahria Town',
    description: 'High-end apartment with panoramic views...',
    price: 12000000,
    location: 'Phase 7',
    city: 'Rawalpindi',
    type: PropertyType.APARTMENT,
    bedrooms: 2,
    bathrooms: 2,
    area: 5,
    areaUnit: 'marla' as const,
    images: ['https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&q=80&w=800'],
    ownerId: 'u2',
    status: PropertyStatus.ACTIVE,
    listingType: ListingType.SELL,
    isAIPredicted: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: '3',
    title: 'Commercial Plaza near Metro',
    description: 'Prime commercial space for business...',
    price: 85000000,
    location: 'Gulberg',
    city: 'Lahore',
    type: PropertyType.COMMERCIAL,
    bedrooms: 0,
    bathrooms: 4,
    area: 1,
    areaUnit: 'kanal' as const,
    images: ['https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800'],
    ownerId: 'u3',
    status: PropertyStatus.ACTIVE,
    listingType: ListingType.SELL,
    isAIPredicted: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }
];

export default function Home() {
  return (
    <div className="space-y-16 pb-20">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=1920" 
            className="w-full h-full object-cover opacity-20"
            alt="Hero Background"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-white via-white/80 to-transparent"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="max-w-3xl"
          >
            <div className="inline-flex items-center space-x-2 bg-amber-50 text-amber-700 px-4 py-2 rounded-full text-[10px] font-black tracking-[0.2em] uppercase mb-8 shadow-sm">
              <Sparkles className="h-4 w-4" />
              <span>Crystal Ball Intelligence</span>
            </div>
            <h1 className="text-7xl font-black text-slate-950 tracking-tight leading-[1.05] mb-8">
              Real Estate <br/><span className="text-indigo-600">Redefined.</span>
            </h1>
            <p className="text-xl text-slate-600 mb-10 leading-relaxed max-w-xl font-medium">
              Predict accurate property prices, get personalized recommendations, and negotiate better with real-time AI market insights.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-5">
              <Link 
                to="/search" 
                className="inline-flex items-center justify-center px-10 py-5 bg-indigo-600 text-white font-black text-base uppercase tracking-widest rounded-2xl hover:bg-indigo-700 transition shadow-2xl shadow-indigo-200 shrink-0"
              >
                Start Exploring
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link 
                to="/predict" 
                className="inline-flex items-center justify-center px-10 py-5 bg-white text-slate-950 border-2 border-slate-100 font-black text-base uppercase tracking-widest rounded-2xl hover:border-indigo-600 transition shadow-sm shrink-0"
              >
                AI Valuer
              </Link>
            </div>

            <div className="mt-12 flex items-center space-x-8">
              <div>
                <p className="text-3xl font-black text-gray-900">10k+</p>
                <p className="text-gray-500 font-medium">Verified Listings</p>
              </div>
              <div className="w-px h-8 bg-gray-200"></div>
              <div>
                <p className="text-3xl font-black text-gray-900">98%</p>
                <p className="text-gray-500 font-medium">AI Accuracy</p>
              </div>
              <div className="w-px h-8 bg-gray-200"></div>
              <div>
                <p className="text-3xl font-black text-gray-900">24/7</p>
                <p className="text-gray-500 font-medium">Agent Support</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-8 gap-4">
          <div>
            <h2 className="text-3xl font-black text-gray-900 mb-2">Featured Listings</h2>
            <p className="text-gray-500">Handpicked properties with AI-estimated fair value reports.</p>
          </div>
          <Link to="/search" className="text-blue-600 font-bold hover:underline inline-flex items-center">
            View All <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {mockProperties.map((p, i) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <PropertyCard property={p as any} />
            </motion.div>
          ))}
        </div>
      </section>

      {/* Features Grid */}
      <section className="bg-gray-900 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-white text-4xl font-black mb-4 tracking-tight">Smart Prop Features</h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">Innovative tools designed to make your property journey secure and data-driven.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: Sparkles,
                title: 'AI Price Prediction',
                description: 'Get real-time fair market value estimates based on area, historical data, and demand trends.',
                color: 'bg-purple-500'
              },
              {
                icon: Map,
                title: 'Location Intelligence',
                description: 'Interactive heatmaps showing price trends, safety scores, and nearby amenities automatically.',
                color: 'bg-blue-500'
              },
              {
                icon: ShieldCheck,
                title: 'Verified Listings',
                description: 'Every property goes through a rigorous validation process to ensure legal status and owner authenticity.',
                color: 'bg-emerald-500'
              }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -8 }}
                className="bg-white/5 border border-white/10 p-8 rounded-3xl backdrop-blur-xl"
              >
                <div className={`${feature.color} w-14 h-14 rounded-2xl flex items-center justify-center mb-6`}>
                  <feature.icon className="h-7 w-7 text-white" />
                </div>
                <h3 className="text-white text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-gray-400 leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Market Trends */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-indigo-600 rounded-[3rem] p-16 overflow-hidden relative shadow-2xl shadow-indigo-100">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-500 rounded-full blur-[120px] -mr-48 -mt-48 opacity-30"></div>
          <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-16">
            <div className="max-w-xl">
              <h3 className="text-white text-5xl font-black mb-8 leading-tight">Insightful decisions <br/>at speed.</h3>
              <p className="text-indigo-100 text-xl font-medium mb-10 leading-relaxed">
                Join thousands of users who utilize SmartProp AI to analyze millions of data points every day for total market transparency.
              </p>
              <div className="flex gap-4">
                <Link to="/predict" className="bg-amber-500 text-indigo-950 px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-sm hover:bg-amber-400 transition shadow-xl shadow-indigo-800/20">
                  Try AI Valuation
                </Link>
                <Link to="/calculator" className="bg-white/10 text-white border border-white/20 px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-sm hover:bg-white/20 transition backdrop-blur-md">
                  Calculator
                </Link>
              </div>
            </div>
            <div className="bg-slate-900/40 border border-white/10 p-10 rounded-[2.5rem] backdrop-blur-xl w-full lg:w-[450px]">
              <div className="flex items-center justify-between mb-10">
                 <span className="text-amber-500 font-black uppercase tracking-[0.2em] text-[10px]">Market Velocity</span>
                 <TrendingUp className="text-emerald-400 h-6 w-6" />
              </div>
              <div className="space-y-8">
                {[
                  { label: "Islamabad Sector F-7", growth: "+12.4%", trend: "up" },
                  { label: "Lahore Gulberg III", growth: "+8.2%", trend: "up" },
                  { label: "Karachi DHA Ph 8", growth: "+4.1%", trend: "up" },
                ].map((item, i) => (
                  <div key={i} className="flex justify-between items-center bg-transparent border-none p-0 outline-none">
                    <span className="text-white font-bold text-lg">{item.label}</span>
                    <span className="text-emerald-400 font-black bg-emerald-400/10 px-3 py-1.5 rounded-xl text-xs">{item.growth}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
