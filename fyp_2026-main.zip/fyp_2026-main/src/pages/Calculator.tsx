import React, { useState, useEffect } from 'react';
import { Calculator as CalcIcon, Percent, Calendar, Wallet, Info, ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

export default function MortgageCalculator() {
  const [loanAmount, setLoanAmount] = useState(10000000);
  const [downPayment, setDownPayment] = useState(2000000);
  const [interestRate, setInterestRate] = useState(14); // Average rate in Pak
  const [loanTerm, setLoanTerm] = useState(20);

  const [monthlyPayment, setMonthlyPayment] = useState(0);

  useEffect(() => {
    const principal = loanAmount - downPayment;
    const monthlyRate = (interestRate / 100) / 12;
    const numberOfPayments = loanTerm * 12;

    if (principal > 0 && monthlyRate > 0) {
      const payment = (principal * monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / (Math.pow(1 + monthlyRate, numberOfPayments) - 1);
      setMonthlyPayment(payment);
    } else {
      setMonthlyPayment(0);
    }
  }, [loanAmount, downPayment, interestRate, loanTerm]);

  const totalPayment = monthlyPayment * loanTerm * 12;
  const totalInterest = totalPayment - (loanAmount - downPayment);

  const data = [
    { name: 'Principal', value: loanAmount - downPayment, color: '#2563eb' },
    { name: 'Interest', value: totalInterest, color: '#8b5cf6' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center mb-16">
        <div className="inline-flex items-center space-x-2 bg-indigo-50 text-indigo-700 px-4 py-1.5 rounded-full text-[10px] font-black tracking-[0.2em] uppercase mb-8 shadow-sm">
          <CalcIcon className="h-4 w-4" />
          <span>Finance Intelligence</span>
        </div>
        <h1 className="text-6xl font-black text-slate-950 mb-6 tracking-tight leading-tight">Mortgage <br/><span className="text-indigo-600">Planner.</span></h1>
        <p className="text-slate-500 text-lg max-w-2xl mx-auto font-medium leading-relaxed">Plan your investment with precision. Calculate installments and total interest over the loan tenure.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start">
        {/* Controls */}
        <div className="lg:col-span-2 bg-white rounded-[3rem] border border-slate-100 shadow-2xl shadow-indigo-50/50 p-12 space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div className="space-y-4">
              <div className="flex justify-between">
                <label className="text-sm font-black text-slate-900 uppercase">Property Price</label>
                <span className="text-sm font-black text-indigo-600">Rs. {loanAmount.toLocaleString()}</span>
              </div>
              <input 
                type="range" 
                min="1000000" 
                max="500000000" 
                step="500000"
                value={loanAmount}
                onChange={(e) => setLoanAmount(Number(e.target.value))}
                className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-bold uppercase">
                <span>1M</span>
                <span>500M</span>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between">
                <label className="text-sm font-black text-slate-900 uppercase">Down Payment</label>
                <span className="text-sm font-black text-indigo-600">Rs. {downPayment.toLocaleString()}</span>
              </div>
              <input 
                type="range" 
                min="0" 
                max={loanAmount} 
                step="100000"
                value={downPayment}
                onChange={(e) => setDownPayment(Number(e.target.value))}
                className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-bold uppercase">
                <span>0</span>
                <span>{Math.round((downPayment/loanAmount)*100)}% of price</span>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center bg-transparent border-none p-0 outline-none">
                <label className="text-sm font-black text-gray-900 uppercase">Interest Rate (%)</label>
                <div className="flex items-center gap-2 bg-gray-50 rounded-xl px-3 py-2">
                   <Percent className="h-4 w-4 text-gray-400" />
                   <input 
                      type="number" 
                      value={interestRate} 
                      onChange={(e) => setInterestRate(Number(e.target.value))}
                      className="w-12 bg-transparent font-black text-blue-600 text-sm focus:ring-0 border-none p-0"
                   />
                </div>
              </div>
              <input 
                type="range" 
                min="1" 
                max="30" 
                step="0.5"
                value={interestRate}
                onChange={(e) => setInterestRate(Number(e.target.value))}
                className="w-full h-2 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center bg-transparent border-none p-0 outline-none">
                <label className="text-sm font-black text-gray-900 uppercase">Loan Term (Years)</label>
                <div className="flex items-center gap-2 bg-gray-50 rounded-xl px-3 py-2">
                   <Calendar className="h-4 w-4 text-gray-400" />
                   <input 
                      type="number" 
                      value={loanTerm} 
                      onChange={(e) => setLoanTerm(Number(e.target.value))}
                      className="w-12 bg-transparent font-black text-blue-600 text-sm focus:ring-0 border-none p-0"
                   />
                </div>
              </div>
              <input 
                type="range" 
                min="1" 
                max="30" 
                value={loanTerm}
                onChange={(e) => setLoanTerm(Number(e.target.value))}
                className="w-full h-2 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
            </div>
          </div>

          <div className="pt-10 border-t border-gray-50 flex items-start gap-4">
            <div className="bg-blue-50 p-3 rounded-2xl shrink-0">
               <Info className="h-6 w-6 text-blue-600" />
            </div>
            <div>
               <p className="text-sm font-bold text-gray-900 mb-1">AI Recommendation</p>
               <p className="text-xs text-gray-500 leading-relaxed">
                  Based on current market trends in Pakistan, a 20% down payment is recommended for the best interest rates from commercial banks like HBL and Bank Alfalah.
               </p>
            </div>
          </div>
        </div>

        {/* Results Card */}
        <div className="space-y-8 lg:sticky lg:top-32">
          <div className="bg-slate-950 rounded-[3rem] p-12 text-white shadow-2xl shadow-indigo-100">
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-amber-500 mb-8">Monthly Installment</p>
            <h2 className="text-6xl font-black mb-12 leading-tight">
              Rs. {Math.round(monthlyPayment).toLocaleString()}
            </h2>
            
            <div className="space-y-6 pt-10 border-t border-white/10">
              <div className="flex justify-between items-center bg-transparent border-none p-0 outline-none">
                 <span className="text-slate-400 text-sm font-bold">Principal Amount</span>
                 <span className="font-black text-lg">Rs. {(loanAmount - downPayment).toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center bg-transparent border-none p-0 outline-none">
                 <span className="text-slate-400 text-sm font-bold">Total Interest</span>
                 <span className="font-black text-lg text-indigo-400">Rs. {Math.round(totalInterest).toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center bg-transparent border-none p-0 outline-none">
                 <span className="text-slate-400 text-sm font-bold">Total Payable</span>
                 <span className="font-black text-2xl text-white">Rs. {Math.round(totalPayment).toLocaleString()}</span>
              </div>
            </div>

            <div className="mt-12 h-48 w-full bg-transparent outline-none ring-0">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={8}
                    dataKey="value"
                  >
                    {data.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-gray-100 p-8 shadow-sm">
             <div className="flex items-center gap-4 mb-6">
                <div className="bg-emerald-50 p-2 rounded-xl">
                   <Wallet className="h-5 w-5 text-emerald-600" />
                </div>
                <h4 className="font-bold text-gray-900">Partner Banks</h4>
             </div>
             <div className="space-y-4">
                {['Meezan Bank', 'Standard Chartered', 'Dubai Islamic Bank'].map((bank) => (
                   <button key={bank} className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition group">
                      <span className="text-sm font-medium text-gray-700">{bank}</span>
                      <ArrowUpRight className="h-4 w-4 text-gray-400 group-hover:text-blue-600 transition" />
                   </button>
                ))}
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}
