import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Search, Send, Phone, Info, MoreVertical, 
  MapPin, Clock, CheckCheck, User, MessageSquare
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const mockChats = [
  { id: '1', name: 'Zeeshan Khan', lastMsg: 'Is the property still available?', time: '2m ago', unread: 2, avatar: 'ZK' },
  { id: '2', name: 'Sarah Ahmed', lastMsg: 'Can we schedule a visit tomorrow?', time: '1h ago', unread: 0, avatar: 'SA' },
  { id: '3', name: 'SmartProp AI', lastMsg: 'Market report for F-7 is ready.', time: '3h ago', unread: 0, avatar: 'AI', isAI: true },
];

const mockMessages = [
  { id: 'm1', sender: 'them', text: 'Hello, I saw your listing for the F-7 villa.', time: '10:00 AM' },
  { id: 'm2', sender: 'me', text: 'Hi! Yes, it is still available. Would you like more details?', time: '10:02 AM' },
  { id: 'm3', sender: 'them', text: 'Yes, is the price negotiable?', time: '10:05 AM' },
  { id: 'm4', sender: 'me', text: 'We can discuss that during a site visit. When are you free?', time: '10:10 AM' },
];

export default function Messaging() {
  const [activeChat, setActiveChat] = useState(mockChats[0]);
  const [msgInput, setMsgInput] = useState('');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 h-[calc(100vh-130px)] bg-transparent outline-none ring-0">
      <div className="bg-white h-full rounded-[2.5rem] border border-gray-100 shadow-2xl flex overflow-hidden">
        
        {/* Sidebar: Chat List */}
        <div className="w-full md:w-96 border-r border-slate-100 flex flex-col shrink-0">
          <div className="p-10 border-b border-slate-100">
             <h2 className="text-4xl font-black text-slate-950 tracking-tight mb-8">Inbox</h2>
             <div className="relative">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Search chats..."
                  className="w-full pl-14 pr-4 py-5 bg-slate-50 border-none rounded-[1.5rem] text-[11px] font-black uppercase tracking-widest focus:ring-2 focus:ring-indigo-100"
                />
             </div>
          </div>
          
          <div className="flex-grow overflow-y-auto">
             {mockChats.map((chat) => (
               <button 
                 key={chat.id}
                 onClick={() => setActiveChat(chat)}
                 className={`w-full p-8 flex items-center gap-6 transition-all border-b border-slate-50 ${activeChat?.id === chat.id ? 'bg-indigo-50/50 border-indigo-100' : 'hover:bg-slate-50'}`}
               >
                  <div className={`w-16 h-16 rounded-[1.5rem] flex items-center justify-center font-black text-xl shadow-lg shrink-0 ${chat.isAI ? 'bg-slate-950 text-white' : 'bg-white text-slate-950 border border-slate-100'}`}>
                     {chat.avatar}
                  </div>
                  <div className="text-left flex-grow">
                     <div className="flex justify-between items-start mb-1">
                        <h4 className="font-black text-slate-950 text-lg leading-none">{chat.name}</h4>
                        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{chat.time}</span>
                     </div>
                     <p className={`text-xs truncate max-w-[150px] ${chat.unread > 0 ? 'text-indigo-600 font-bold' : 'text-slate-500 font-medium'}`}>
                        {chat.lastMsg}
                     </p>
                  </div>
                  {chat.unread > 0 && (
                    <div className="w-6 h-6 bg-indigo-600 rounded-full flex items-center justify-center shadow-lg shadow-indigo-200">
                       <span className="text-[10px] font-black text-white">{chat.unread}</span>
                    </div>
                  )}
               </button>
             ))}
          </div>
        </div>

        {/* Chat Window */}
        <div className="hidden md:flex flex-grow flex-col relative">
           {/* Chat Header */}
           <div className="p-8 border-b border-gray-100 flex items-center justify-between">
              <div className="flex items-center gap-4">
                 <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black ${activeChat?.isAI ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-900'}`}>
                    {activeChat?.avatar}
                 </div>
                 <div>
                    <h3 className="font-black text-gray-900">{activeChat?.name}</h3>
                    <p className="text-xs text-emerald-600 font-black flex items-center">
                       <span className="w-1.5 h-1.5 bg-emerald-600 rounded-full mr-2"></span>
                       Online
                    </p>
                 </div>
              </div>
              <div className="flex items-center gap-2">
                 <button className="p-3 bg-gray-50 text-gray-500 rounded-xl hover:bg-gray-100 transition">
                    <Phone className="h-5 w-5" />
                 </button>
                 <button className="p-3 bg-gray-50 text-gray-500 rounded-xl hover:bg-gray-100 transition">
                    <Info className="h-5 w-5" />
                 </button>
                 <button className="p-3 bg-gray-50 text-gray-500 rounded-xl hover:bg-gray-100 transition">
                    <MoreVertical className="h-5 w-5" />
                 </button>
              </div>
           </div>

           {/* Property Context Header (Module 7 Integration) */}
           <div className="bg-blue-50/50 p-4 border-b border-blue-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                 <div className="w-10 h-10 bg-white rounded-lg border border-blue-100 overflow-hidden"></div>
                 <div>
                    <p className="text-xs font-black text-gray-900">Inquiry: Modern Villa F-7</p>
                    <p className="text-[10px] font-bold text-blue-600">Rs. 4.5 Crore</p>
                 </div>
              </div>
              <Link to="/property/1" className="text-[10px] font-black uppercase tracking-widest text-blue-600 hover:underline">
                 View Listing
              </Link>
           </div>

           {/* Chat Messages */}
           <div className="flex-grow overflow-y-auto p-12 space-y-10 bg-slate-50/30">
              {mockMessages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}>
                   <div className={`max-w-md ${msg.sender === 'me' ? 'bg-indigo-600 text-white rounded-l-[2rem] rounded-tr-[2rem] shadow-2xl shadow-indigo-100' : 'bg-white text-slate-950 border border-slate-100 rounded-r-[2rem] rounded-tl-[2rem] shadow-sm'} p-8`}>
                      <p className="text-base font-medium leading-relaxed">{msg.text}</p>
                      <div className="mt-3 flex items-center justify-end gap-2 opacity-50">
                         <span className="text-[10px] font-black uppercase tracking-[0.1em]">{msg.time}</span>
                         {msg.sender === 'me' && <CheckCheck className="h-4 w-4" />}
                      </div>
                   </div>
                </div>
              ))}
           </div>

           {/* Message Input */}
           <div className="p-10 border-t border-slate-100 bg-white">
              <form 
                onSubmit={(e) => e.preventDefault()}
                className="bg-slate-50 rounded-[2rem] p-3 flex items-center gap-6 border-2 border-transparent focus-within:border-indigo-600 focus-within:bg-white transition-all shadow-inner"
              >
                 <input 
                   type="text" 
                   placeholder="Write your response..."
                   className="flex-grow bg-transparent border-none text-base font-bold focus:ring-0 placeholder:text-slate-400 px-6"
                   value={msgInput}
                   onChange={(e) => setMsgInput(e.target.value)}
                 />
                 <button 
                   type="submit"
                   className="w-14 h-14 bg-indigo-600 text-white rounded-2xl shadow-2xl shadow-indigo-200 hover:bg-indigo-700 transition flex items-center justify-center"
                 >
                    <Send className="h-6 w-6" />
                 </button>
              </form>
              <div className="mt-4 flex gap-4">
                 <button className="text-[10px] font-black uppercase border border-gray-200 px-3 py-1.5 rounded-lg text-gray-400 hover:border-blue-600 hover:text-blue-600 transition">Is it still for sale?</button>
                 <button className="text-[10px] font-black uppercase border border-gray-200 px-3 py-1.5 rounded-lg text-gray-400 hover:border-blue-600 hover:text-blue-600 transition">Send My Contact</button>
              </div>
           </div>
        </div>

        {/* Right Sidebar: Chat Context/Tools (Empty for now) */}
        {!activeChat?.isAI && (
           <div className="hidden xl:block w-72 border-l border-gray-100 p-8 space-y-10">
              <div>
                 <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-4">Contact Info</h4>
                 <div className="flex flex-col items-center text-center">
                    <div className="w-20 h-20 bg-gray-100 rounded-[1.5rem] mb-4 flex items-center justify-center text-2xl font-black">
                       {activeChat?.avatar}
                    </div>
                    <p className="font-black text-gray-900">{activeChat?.name}</p>
                    <p className="text-xs text-gray-500 font-medium">Verified Buyer</p>
                 </div>
              </div>
              
              <div className="space-y-4">
                 <button className="w-full py-3 bg-gray-900 text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-gray-800 transition">Schedule Visit</button>
                 <button className="w-full py-3 bg-white border border-gray-200 text-gray-900 rounded-xl text-xs font-black uppercase tracking-widest hover:border-blue-600 transition">View Profile</button>
              </div>

              <div className="bg-blue-50 p-6 rounded-2xl">
                 <div className="flex items-center gap-2 mb-2">
                    <Clock className="h-4 w-4 text-blue-600" />
                    <span className="text-[10px] font-black text-blue-900 uppercase">Response Time</span>
                 </div>
                 <p className="text-xs text-blue-700 font-bold">Fast · 30m response</p>
              </div>
           </div>
        )}
      </div>
    </div>
  );
}
