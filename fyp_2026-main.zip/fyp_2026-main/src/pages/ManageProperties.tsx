import React, { useState } from 'react';
import { 
  Building, MapPin, DollarSign, Camera, Plus, 
  Trash2, Edit3, Loader2, CheckCircle2, AlertCircle, Info, Sparkles, X, ChevronRight, MessageSquare
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ListingType, PropertyType } from '../types';
import { cn } from '../lib/utils';

export default function ManageProperties() {
  const [isAdding, setIsAdding] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  // Form state
  const [form, setForm] = useState({
    title: '',
    location: '',
    city: 'Islamabad',
    price: '',
    type: 'house',
    listingType: 'sell',
    area: '',
    areaUnit: 'marla',
    bedrooms: '',
    bathrooms: '',
    description: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        setIsAdding(false);
      }, 2000);
    }, 1500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-16 gap-8">
        <div>
           <div className="inline-flex items-center space-x-2 bg-indigo-50 text-indigo-700 px-4 py-1.5 rounded-full text-[10px] font-black tracking-[0.2em] uppercase mb-4 shadow-sm">
             <Building className="h-4 w-4" />
             <span>Portfolio Intelligence</span>
           </div>
           <h1 className="text-6xl font-black text-slate-950 tracking-tight leading-[1.05]">Property <br/><span className="text-indigo-600">Inventory.</span></h1>
           <p className="text-slate-500 font-medium mt-6 max-w-md leading-relaxed">Manage your listings, track analytics, and optimize prices with AI forecasting.</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-indigo-600 text-white px-10 py-5 rounded-[1.5rem] font-black text-lg uppercase tracking-widest hover:bg-indigo-700 transition shadow-2xl shadow-indigo-100 flex items-center gap-4 lg:w-auto w-full justify-center"
        >
          <Plus className="h-6 w-6" />
          Add Listing
        </button>
      </div>

      {/* Stats Quick View */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
         {[
           { label: 'Active Listings', value: '4', color: 'text-indigo-600', icon: Building },
           { label: 'Total Inquiries', value: '28', color: 'text-emerald-600', icon: MessageSquare },
           { label: 'Pending Approvals', value: '1', color: 'text-amber-500', icon: AlertCircle },
         ].map((stat, i) => (
           <div key={i} className="bg-white border border-slate-100 p-10 rounded-[3rem] shadow-2xl shadow-slate-100/50 flex flex-col justify-between h-48">
              <div className="flex justify-between items-start">
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{stat.label}</p>
                 <stat.icon className={`h-5 w-5 ${stat.color} opacity-40`} />
              </div>
              <p className={`text-5xl font-black ${stat.color} tracking-tighter`}>{stat.value}</p>
           </div>
         ))}
      </div>

      {/* Listings Table Placeholder */}
      <div className="bg-white rounded-[3rem] border border-slate-100 overflow-hidden shadow-2xl shadow-slate-100/50">
         <div className="p-10 border-b border-slate-100 flex justify-between items-center bg-slate-50/30">
            <h3 className="text-xl font-black text-slate-950 uppercase tracking-tight">Active Portfolio</h3>
            <div className="flex gap-2 bg-slate-100 p-1.5 rounded-2xl">
               <button className="px-5 py-2.5 bg-white shadow-md rounded-xl text-[10px] font-black uppercase tracking-widest text-indigo-700">All Assets</button>
               <button className="px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-400">Sold</button>
            </div>
         </div>
         
         <div className="overflow-x-auto">
            <table className="w-full text-left">
               <thead>
                  <tr className="bg-white">
                     <th className="px-10 py-6 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">Listing Identity</th>
                     <th className="px-10 py-6 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">Security Status</th>
                     <th className="px-10 py-6 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">IQ Metrics</th>
                     <th className="px-10 py-6 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em]">Valuation</th>
                     <th className="px-10 py-6 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] text-right">Operations</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-slate-50">
                  {[1,2,3].map((item) => (
                    <tr key={item} className="hover:bg-slate-50/50 transition">
                       <td className="px-10 py-8">
                          <div className="flex items-center gap-5">
                             <div className="w-16 h-16 rounded-2xl bg-slate-100 shrink-0 border border-slate-200"></div>
                             <div>
                                <p className="font-black text-slate-950 text-lg leading-none mb-2">Modern Villa F-7</p>
                                <p className="text-xs text-slate-500 font-bold flex items-center">
                                   <MapPin className="h-3 w-3 mr-1 text-indigo-600" />
                                   Islamabad, PK
                                </p>
                             </div>
                          </div>
                       </td>
                       <td className="px-10 py-8">
                          <span className="bg-emerald-400/10 text-emerald-600 text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest border border-emerald-400/20">Verified</span>
                       </td>
                       <td className="px-10 py-8">
                          <div className="flex flex-col gap-1">
                             <p className="text-sm font-black text-slate-950">1.2k Views</p>
                             <p className="text-xs text-indigo-600 font-black tracking-wider uppercase">12 Direct Leads</p>
                          </div>
                       </td>
                       <td className="px-10 py-8 font-black text-slate-950 text-base">Rs. 2.4 Cr</td>
                       <td className="px-10 py-8">
                          <div className="flex items-center justify-end gap-3">
                             <button className="p-3 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition border border-transparent hover:border-indigo-100" title="Edit">
                                <Edit3 className="h-5 w-5" />
                             </button>
                             <button className="p-3 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition border border-transparent hover:border-red-100" title="Delete">
                                <Trash2 className="h-5 w-5" />
                             </button>
                          </div>
                       </td>
                    </tr>
                  ))}
               </tbody>
            </table>
         </div>
      </div>

      {/* Add Property Slide-over / Modal */}
      <AnimatePresence>
         {isAdding && (
           <>
             <motion.div 
               initial={{ opacity: 0 }}
               animate={{ opacity: 1 }}
               exit={{ opacity: 0 }}
               onClick={() => !loading && setIsAdding(false)}
               className="fixed inset-0 bg-black/50 z-[100] backdrop-blur-sm"
             />
             <motion.div 
               initial={{ x: '100%' }}
               animate={{ x: 0 }}
               exit={{ x: '100%' }}
               transition={{ type: 'spring', damping: 25, stiffness: 200 }}
               className="fixed top-0 right-0 h-full w-full max-w-2xl bg-white z-[110] shadow-2xl flex flex-col"
             >
                <div className="p-10 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                   <div>
                      <h2 className="text-3xl font-black text-slate-950 tracking-tight uppercase">Deploy Listing</h2>
                      <p className="text-slate-500 font-medium text-sm mt-1">Broadcast your asset to thousands of verified buyers.</p>
                   </div>
                   <button 
                     onClick={() => setIsAdding(false)}
                     className="p-3 bg-white border border-slate-100 hover:border-red-500 hover:text-red-500 rounded-full transition shadow-sm"
                   >
                     <X className="h-6 w-6 text-slate-400" />
                   </button>
                </div>

                <form onSubmit={handleSubmit} className="flex-grow overflow-y-auto p-12 space-y-12 bg-slate-50/20">
                    {/* Step 1: Basic Info */}
                    <div className="space-y-8">
                       <div className="flex items-center gap-4">
                          <div className="bg-indigo-600 p-2.5 rounded-2xl shadow-lg shadow-indigo-100">
                             <Info className="h-4 w-4 text-white" />
                          </div>
                          <h4 className="text-xs font-black uppercase tracking-[0.2em] text-slate-950">Core Identity</h4>
                       </div>
                       
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div className="col-span-full">
                             <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Listing Title</label>
                             <input 
                                type="text" 
                                placeholder="e.g. 10 Marla Corner House with Basement"
                                className="w-full px-6 py-5 bg-white border-2 border-slate-100 rounded-[1.5rem] text-sm font-semibold focus:border-indigo-600 focus:ring-4 focus:ring-indigo-50 transition-all shadow-sm"
                                required
                                onChange={(e) => setForm({...form, title: e.target.value})}
                             />
                          </div>
                          <div>
                             <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Property Category</label>
                             <select className="w-full px-6 py-5 bg-white border-2 border-slate-100 rounded-[1.5rem] text-sm font-semibold focus:border-indigo-600 focus:ring-4 focus:ring-indigo-50 transition-all shadow-sm">
                                <option value="house">House</option>
                                <option value="apartment">Apartment</option>
                                <option value="plot">Plot / Land</option>
                             </select>
                          </div>
                          <div>
                             <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Market Purpose</label>
                             <div className="flex bg-slate-100 p-1.5 rounded-[1.5rem]">
                                <button 
                                  type="button"
                                  className={`flex-grow py-3.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${form.listingType === 'sell' ? 'bg-white shadow-md text-indigo-700' : 'text-slate-400'}`}
                                  onClick={() => setForm({...form, listingType: 'sell'})}
                                >
                                  Sell
                                </button>
                                <button 
                                  type="button"
                                  className={`flex-grow py-3.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${form.listingType === 'rent' ? 'bg-white shadow-md text-indigo-700' : 'text-slate-400'}`}
                                  onClick={() => setForm({...form, listingType: 'rent'})}
                                >
                                  Rent
                                </button>
                             </div>
                          </div>
                       </div>
                    </div>

                    {/* Step 2: Location & Price */}
                    <div className="space-y-8">
                       <div className="flex items-center gap-4">
                          <div className="bg-amber-500 p-2.5 rounded-2xl shadow-lg shadow-amber-200">
                             <MapPin className="h-4 w-4 text-indigo-950" />
                          </div>
                          <h4 className="text-xs font-black uppercase tracking-[0.2em] text-slate-950">Location & Value</h4>
                       </div>
                       
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div>
                             <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Metropolitan City</label>
                             <select className="w-full px-6 py-5 bg-white border-2 border-slate-100 rounded-[1.5rem] text-sm font-semibold focus:border-indigo-600 focus:ring-4 focus:ring-indigo-50 transition-all shadow-sm">
                                <option>Islamabad</option>
                                <option>Lahore</option>
                                <option>Karachi</option>
                             </select>
                          </div>
                          <div>
                             <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Asking Price (PKR)</label>
                             <div className="relative">
                                <DollarSign className="absolute left-6 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                                <input 
                                   type="number" 
                                   placeholder="5,000,000"
                                   className="w-full pl-14 pr-6 py-5 bg-white border-2 border-slate-100 rounded-[1.5rem] text-sm font-semibold focus:border-indigo-600 focus:ring-4 focus:ring-indigo-50 transition-all shadow-sm"
                                   required
                                />
                             </div>
                          </div>
                          <div className="col-span-full">
                            <div className="bg-slate-950 p-6 rounded-[2rem] flex gap-5 border border-slate-800 shadow-2xl">
                               <Sparkles className="h-6 w-6 text-amber-500 shrink-0" />
                               <p className="text-[11px] font-medium text-slate-300 leading-relaxed uppercase tracking-wider">
                                 AI OPTIMIZATION: <span className="text-white">Active listings with AI IQ Badges receive up to 240% more verified impressions. Our neural engine will audit your price upon submission.</span>
                               </p>
                            </div>
                          </div>
                       </div>
                    </div>

                    {/* Step 3: Media */}
                    <div className="space-y-8">
                       <div className="flex items-center gap-4">
                          <div className="bg-indigo-600 p-2.5 rounded-2xl shadow-lg shadow-indigo-200">
                             <Camera className="h-4 w-4 text-white" />
                          </div>
                          <h4 className="text-xs font-black uppercase tracking-[0.2em] text-slate-950">Asset Visualization</h4>
                       </div>
                       
                       <div className="border-4 border-dotted border-slate-100 rounded-[3rem] p-16 flex flex-col items-center justify-center text-center hover:border-indigo-600 hover:bg-indigo-50/30 transition-all cursor-pointer group">
                          <div className="bg-indigo-600 p-6 rounded-full mb-6 group-hover:scale-110 transition-transform shadow-xl shadow-indigo-100">
                             <Plus className="h-10 w-10 text-white" />
                          </div>
                          <p className="font-black text-slate-950 text-lg uppercase tracking-tight">Upload Property Assets</p>
                          <p className="text-xs text-slate-400 mt-2 font-bold">RAW, PNG, JPG up to 25MB each. Highly recommended for AI audit.</p>
                       </div>
                    </div>

                    <button 
                      type="submit"
                      disabled={loading}
                      className="w-full py-6 bg-slate-950 text-white rounded-[2rem] font-black text-xl uppercase tracking-[0.2em] hover:bg-slate-800 transition-all shadow-2xl shadow-slate-200 flex items-center justify-center gap-4 disabled:opacity-50"
                    >
                      {loading ? <Loader2 className="h-8 w-8 animate-spin" /> : (
                        success ? (
                          <div className="flex items-center gap-3 text-emerald-400">
                            <CheckCircle2 className="h-8 w-8" />
                            Asset Deployed.
                          </div>
                        ) : (
                          <div className="flex items-center gap-3">
                             Verify & Publish
                             <ChevronRight className="h-6 w-6 text-amber-500" />
                          </div>
                        )
                      )}
                    </button>
                 </form>
             </motion.div>
           </>
         )}
      </AnimatePresence>
    </div>
  );
}
