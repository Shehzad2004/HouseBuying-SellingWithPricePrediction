import React, { useState } from 'react';
import { Search, MapPin, Filter, SlidersHorizontal, Grid, List as ListIcon, Map as MapIcon, X } from 'lucide-react';
import PropertyCard from '../components/PropertyCard';
import { PropertyType, ListingType, PropertyStatus } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

const mockProperties = [
  {
    id: '1',
    title: 'Modern Villa with Smart Features',
    price: 45000000,
    location: 'Sector F-7',
    city: 'Islamabad',
    type: PropertyType.HOUSE,
    bedrooms: 4,
    bathrooms: 5,
    area: 10,
    areaUnit: 'marla' as const,
    images: ['https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=800'],
    status: PropertyStatus.ACTIVE,
    listingType: ListingType.SELL,
    isAIPredicted: true,
  },
  {
    id: '2',
    title: 'Luxury Apartment in Bahria Town',
    price: 12000000,
    location: 'Phase 7',
    city: 'Rawalpindi',
    type: PropertyType.APARTMENT,
    bedrooms: 2,
    bathrooms: 2,
    area: 5,
    areaUnit: 'marla' as const,
    images: ['https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&q=80&w=800'],
    status: PropertyStatus.ACTIVE,
    listingType: ListingType.SELL,
    isAIPredicted: false,
  },
  {
     id: '4',
     title: 'Elegant Family House',
     price: 32000000,
     location: 'DHA Phase 6',
     city: 'Lahore',
     type: PropertyType.HOUSE,
     bedrooms: 3,
     bathrooms: 3,
     area: 8,
     areaUnit: 'marla' as const,
     images: ['https://images.unsplash.com/photo-1570129477492-45c003edd2be?auto=format&fit=crop&q=80&w=800'],
     status: PropertyStatus.ACTIVE,
     listingType: ListingType.SELL,
     isAIPredicted: true,
  }
];

export default function SearchPage() {
  const [view, setView] = useState<'grid' | 'list' | 'map'>('grid');
  const [showFilters, setShowFilters] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="flex flex-col h-[calc(100vh-64px)] overflow-hidden">
      {/* Top Filter Bar */}
      <div className="bg-white border-b border-slate-200 px-4 sm:px-6 lg:px-8 py-6 shrink-0">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center gap-6">
          <div className="relative flex-grow w-full group">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 group-focus-within:text-indigo-600 transition-colors" />
            <input 
              type="text" 
              placeholder="Search by city, location, or project name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-14 pr-4 py-4 bg-slate-50 border-2 border-transparent focus:bg-white focus:ring-4 focus:ring-indigo-50 focus:border-indigo-600 rounded-[1.5rem] text-sm font-semibold transition-all"
            />
          </div>
          
          <div className="flex items-center gap-3 w-full md:w-auto">
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center justify-center gap-2 px-8 py-4 rounded-[1.5rem] border-2 font-black text-xs uppercase tracking-widest transition-all grow md:grow-0 ${
                showFilters ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-200' : 'bg-white border-slate-100 text-slate-700 hover:border-indigo-600 transition'
              }`}
            >
              <SlidersHorizontal className="h-4 w-4" />
              Filters
            </button>
            
            <div className="h-10 w-px bg-slate-200 hidden md:block mx-3"></div>
            
            <div className="bg-slate-100 p-1.5 rounded-2xl flex items-center shrink-0">
              <button 
                onClick={() => setView('grid')}
                className={`p-2.5 rounded-xl transition-all ${view === 'grid' ? 'bg-white shadow-md text-indigo-600' : 'text-slate-500 hover:text-slate-900'}`}
              >
                <Grid className="h-5 w-5" />
              </button>
              <button 
                onClick={() => setView('list')}
                className={`p-2.5 rounded-xl transition-all ${view === 'list' ? 'bg-white shadow-md text-indigo-600' : 'text-slate-500 hover:text-slate-900'}`}
              >
                <ListIcon className="h-5 w-5" />
              </button>
              <button 
                onClick={() => setView('map')}
                className={`p-2.5 rounded-xl transition-all ${view === 'map' ? 'bg-white shadow-md text-indigo-600' : 'text-slate-500 hover:text-slate-900'}`}
              >
                <MapIcon className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-grow flex overflow-hidden bg-transparent">
        {/* Main Results */}
        <div className={`flex-grow overflow-y-auto p-4 sm:p-6 lg:p-8 ${view === 'map' ? 'hidden md:block md:w-1/2' : 'w-full'}`}>
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center justify-between mb-8">
              <p className="text-gray-500 font-medium">Found <span className="text-gray-900 font-bold">{mockProperties.length}</span> properties matching your criteria</p>
              <select className="bg-transparent text-sm font-bold border-none focus:ring-0 cursor-pointer">
                <option>Newest First</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
                <option>Area: Large to Small</option>
              </select>
            </div>

            <div className={cn(
              "grid gap-8",
              view === 'grid' ? "grid-cols-1 md:grid-cols-2 xl:grid-cols-3" : "grid-cols-1"
            )}>
              {mockProperties.map((p) => (
                <PropertyCard key={p.id} property={p as any} />
              ))}
            </div>
          </div>
        </div>

        {/* Map Placeholder */}
        {view === 'map' && (
          <div className="flex-grow bg-gray-100 flex flex-col items-center justify-center text-center p-12">
            <div className="bg-blue-100 p-6 rounded-full mb-6">
              <MapIcon className="h-12 w-12 text-blue-600" />
            </div>
            <h3 className="text-2xl font-black text-gray-900 mb-4">Interactive Map Search</h3>
            <p className="text-gray-500 max-w-sm mb-8">
              Explore listings geographically. Map view is being integrated with Google Maps platform API.
            </p>
            <button 
              onClick={() => setView('grid')}
              className="px-8 py-3 bg-white text-gray-900 border border-gray-200 rounded-xl font-bold shadow-sm"
            >
              Return to Gallery
            </button>
          </div>
        )}

        {/* Sidebar Map for Mixed View */}
        {view !== 'map' && view !== 'list' && (
          <div className="hidden xl:block w-96 border-l border-gray-200 bg-gray-50 overflow-hidden relative">
            <div className="absolute inset-0 grayscale opacity-50 bg-[url('https://maps.googleapis.com/maps/api/staticmap?center=33.6844,73.0479&zoom=12&size=600x1200&sensor=false&key=')] bg-cover"></div>
            <div className="absolute inset-0 flex items-center justify-center p-8">
               <div className="bg-white/80 backdrop-blur-md p-6 rounded-2xl shadow-xl text-center">
                  <p className="text-sm font-bold text-gray-900 mb-2">Map View Preview</p>
                  <p className="text-xs text-gray-500">Enable map view to see exact locations and nearby amenities.</p>
               </div>
            </div>
          </div>
        )}
      </div>

      {/* Filter Overlay */}
      <AnimatePresence>
        {showFilters && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowFilters(false)}
              className="fixed inset-0 bg-black/50 z-[60] backdrop-blur-sm"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 h-full w-full max-w-md bg-white z-[70] shadow-2xl p-8 flex flex-col"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-2xl font-black text-gray-900">Filters</h3>
                <button 
                  onClick={() => setShowFilters(false)}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="flex-grow space-y-8 overflow-y-auto pr-2">
                <div>
                  <label className="block text-sm font-bold text-gray-900 mb-4 uppercase tracking-wider">Property Type</label>
                  <div className="grid grid-cols-2 gap-3">
                    {['House', 'Apartment', 'Plot', 'Commercial'].map((type) => (
                      <button key={type} className="px-4 py-3 rounded-xl border border-gray-200 text-sm font-medium hover:border-blue-600 transition">
                        {type}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-900 mb-4 uppercase tracking-wider">Price Range (PKR)</label>
                  <div className="flex items-center gap-4">
                    <input type="number" placeholder="Min" className="w-full px-4 py-3 bg-gray-50 border-none rounded-xl text-sm" />
                    <span className="text-gray-400 font-bold">—</span>
                    <input type="number" placeholder="Max" className="w-full px-4 py-3 bg-gray-50 border-none rounded-xl text-sm" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-900 mb-4 uppercase tracking-wider">Bedrooms</label>
                  <div className="flex gap-2">
                    {['Any', '1', '2', '3', '4', '5+'].map((num) => (
                      <button key={num} className="w-10 h-10 rounded-lg border border-gray-200 text-xs font-bold hover:bg-blue-600 hover:text-white transition">
                        {num}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-8 mt-8 border-t border-slate-100 grid grid-cols-2 gap-4 bg-transparent outline-none ring-0">
                <button className="py-4 text-slate-500 font-black uppercase tracking-widest text-[10px] hover:text-slate-950 transition outline-none">
                  Reset All
                </button>
                <button className="py-4 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-indigo-700 shadow-2xl shadow-indigo-100 transition">
                  Apply Filters
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
