import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  MapPin, BedDouble, Bath, Square, Sparkles, Heart, 
  MessageSquare, Phone, Calendar, Share2, Info, ChevronRight,
  TrendingUp, ShieldCheck
} from 'lucide-react';
import { Property, PropertyType, ListingType, PropertyStatus } from '../types';
import { motion } from 'motion/react';

// Mock function to "fetch" a property
const getProperty = (id: string) => ({
  id,
  title: 'Modern Villa with Smart Features',
  description: 'Experience luxury living in this architectural masterpiece. This villa offers a unique blend of modern design and functional living spaces. Featuring double-glazed windows, centralized heating, and a state-of-the-art security system. The garden is landscaped with exotic plants and features a private infinity pool. Located in the most prestigious sector of Islamabad with easy access to all main roads and amenities.',
  price: 45000000,
  location: 'Sector F-7',
  city: 'Islamabad',
  type: PropertyType.HOUSE,
  bedrooms: 4,
  bathrooms: 5,
  area: 10,
  areaUnit: 'marla' as const,
  images: [
    'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=1200',
    'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=1200',
    'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1200'
  ],
  ownerId: 'u1',
  status: PropertyStatus.ACTIVE,
  listingType: ListingType.SELL,
  isAIPredicted: true,
  aiEstimatedPrice: 43500000,
  aiConfidenceScore: 0.92,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
});

export default function PropertyDetail() {
  const { id } = useParams();
  const [property] = useState(getProperty(id || '1'));
  const [activeImage, setActiveImage] = useState(0);

  return (
    <div className="bg-white min-h-screen pb-20">
      {/* Header Info */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="flex flex-col md:flex-row justify-between items-start gap-6 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <span className="bg-indigo-600 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest shadow-lg shadow-indigo-100">
                For {property.listingType}
              </span>
              <div className="flex items-center text-slate-500 text-sm font-medium">
                <MapPin className="h-4 w-4 mr-1 text-indigo-600" />
                {property.location}, {property.city}
              </div>
            </div>
            <h1 className="text-5xl font-black text-slate-950 tracking-tight mb-2 leading-none">{property.title}</h1>
            <p className="text-[11px] text-slate-400 font-bold uppercase tracking-[0.2em]">Listing ID / SP-{property.id}</p>
          </div>
          
          <div className="text-left md:text-right">
            <p className="text-[10px] uppercase tracking-[0.4em] text-slate-400 font-black mb-1">Asking Price</p>
            <h2 className="text-5xl font-black text-indigo-700">
              Rs. {property.price.toLocaleString()}
            </h2>
            {property.isAIPredicted && (
              <div className="mt-4 inline-flex items-center gap-2 bg-amber-50 text-amber-700 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider border border-amber-100 shadow-sm">
                 <Sparkles className="h-4 w-4" />
                 AI Intelligence / Rs. {property.aiEstimatedPrice?.toLocaleString()}
              </div>
            )}
          </div>
        </div>

        {/* Gallery */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 h-[500px] mb-12">
           <div className="lg:col-span-2 relative rounded-[2rem] overflow-hidden group">
              <img 
                src={property.images[activeImage]} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
                alt="Property main"
              />
              <div className="absolute bottom-6 left-6 flex space-x-2">
                 <button className="p-3 bg-white/80 backdrop-blur-md rounded-full shadow-lg hover:bg-white transition">
                    <Heart className="h-5 w-5 text-gray-900" />
                 </button>
                 <button className="p-3 bg-white/80 backdrop-blur-md rounded-full shadow-lg hover:bg-white transition">
                    <Share2 className="h-5 w-5 text-gray-900" />
                 </button>
              </div>
           </div>
           <div className="hidden lg:grid grid-rows-2 gap-4">
              {property.images.slice(1, 3).map((img, i) => (
                <div key={i} className="relative rounded-[2rem] overflow-hidden cursor-pointer group" onClick={() => setActiveImage(i+1)}>
                   <img src={img} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" alt={`Property ${i+1}`} />
                   {i === 1 && property.images.length > 3 && (
                     <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <span className="text-white text-xl font-black">+{property.images.length - 3} Photos</span>
                     </div>
                   )}
                </div>
              ))}
           </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start">
          {/* Details Content */}
          <div className="lg:col-span-2 space-y-12">
            {/* Quick Stats */}
            <div className="bg-gray-50 rounded-[2.5rem] p-8 flex flex-wrap gap-12 justify-center sm:justify-start">
               <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm">
                    <BedDouble className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Bedrooms</p>
                    <p className="text-lg font-black text-gray-900">{property.bedrooms} Beds</p>
                  </div>
               </div>
               <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm">
                    <Bath className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Bathrooms</p>
                    <p className="text-lg font-black text-gray-900">{property.bathrooms} Baths</p>
                  </div>
               </div>
               <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm">
                    <Square className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Property Area</p>
                    <p className="text-lg font-black text-gray-900">{property.area} <span className="text-xs uppercase text-gray-400 font-bold">{property.areaUnit}</span></p>
                  </div>
               </div>
            </div>

            {/* Description */}
            <div>
               <h3 className="text-2xl font-black text-gray-900 mb-6">Property Overview</h3>
               <p className="text-gray-600 leading-loose text-lg font-medium">
                  {property.description}
               </p>
            </div>

            {/* AI Insights Segment */}
            <div className="bg-slate-950 rounded-[3rem] p-12 text-white relative overflow-hidden shadow-2xl shadow-indigo-100">
               <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-600 rounded-full blur-[100px] -mr-40 -mt-40 opacity-30"></div>
               <div className="relative z-10">
                  <div className="flex items-center gap-4 mb-10">
                     <div className="bg-amber-500 p-2.5 rounded-2xl">
                        <Sparkles className="h-8 w-8 text-indigo-950" />
                     </div>
                     <h3 className="text-3xl font-black tracking-tight leading-none">Property <br/>Intelligence.</h3>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                     <div className="space-y-8">
                        <div className="bg-white/10 border border-white/10 p-8 rounded-[2rem] backdrop-blur-md">
                           <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-4">Market Index</p>
                           <div className="flex items-center justify-between">
                              <span className="text-2xl font-black">Strong Bullish</span>
                              <TrendingUp className="h-7 w-7 text-emerald-400" />
                           </div>
                        </div>
                        <div className="bg-white/10 border border-white/10 p-8 rounded-[2rem] backdrop-blur-md">
                           <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-4">Valuation Confidence</p>
                           <div className="flex items-center justify-between">
                              <span className="text-2xl font-black">92% Reliable</span>
                              <ShieldCheck className="h-7 w-7 text-amber-500" />
                           </div>
                        </div>
                     </div>
                     <div className="bg-white/5 border border-white/5 p-10 rounded-[2rem] flex flex-col justify-between">
                        <p className="text-lg font-medium leading-relaxed italic text-slate-300">
                           "This property is priced slightly above market average, but its high-end finish and proximity to commercial hubs in F-7 justify the premium. Predict 12% price growth in this specific block over next 14 months."
                        </p>
                        <div className="mt-12 flex items-center justify-between pt-8 border-t border-white/5">
                           <span className="text-[10px] font-black uppercase tracking-[0.2em] text-amber-500">AI Forecaster v3.0</span>
                           <Link to="/predict" className="text-xs font-black uppercase tracking-widest text-white underline underline-offset-8 decoration-indigo-500 decoration-2">Deep Audit</Link>
                        </div>
                     </div>
                  </div>
               </div>
            </div>

            {/* Nearby Locations */}
            <div>
               <h3 className="text-2xl font-black text-gray-900 mb-6">Nearby Amenities</h3>
               <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { label: 'Schools', value: '3 within 1km' },
                    { label: 'Hospitals', value: '2 within 2km' },
                    { label: 'Markets', value: 'Safat Market (5min)' },
                    { label: 'Parks', value: 'Fatima Jinnah (10min)' },
                  ].map((amenity, i) => (
                    <div key={i} className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm text-center">
                       <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-2">{amenity.label}</p>
                       <p className="text-sm font-bold text-gray-900">{amenity.value}</p>
                    </div>
                  ))}
               </div>
            </div>
          </div>

          {/* Contact Card Sticky */}
          <div className="lg:sticky lg:top-32 space-y-6">
             <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-2xl p-8">
                <div className="flex items-center gap-4 mb-8">
                   <div className="w-16 h-16 bg-gray-100 rounded-full overflow-hidden">
                      <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=100" alt="Agent" />
                   </div>
                   <div>
                      <h4 className="text-lg font-black text-gray-900">Zeeshan Khan</h4>
                      <p className="text-sm text-gray-500 font-medium">Verified Platinum Agent</p>
                   </div>
                </div>

                <div className="space-y-4">
                   <button className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black text-lg uppercase tracking-widest text-sm hover:bg-indigo-700 transition shadow-2xl shadow-indigo-100 flex items-center justify-center gap-3">
                      <MessageSquare className="h-5 w-5" />
                      Instant Message
                   </button>
                   <button className="w-full py-5 border-2 border-slate-100 text-slate-950 rounded-2xl font-black text-lg uppercase tracking-widest text-sm hover:border-indigo-600 transition flex items-center justify-center gap-3">
                      <Phone className="h-5 w-5" />
                      View Contact
                   </button>
                   <button className="w-full py-5 bg-slate-950 text-white rounded-2xl font-black uppercase tracking-widest text-sm flex items-center justify-center gap-3 hover:bg-slate-800 transition shadow-xl shadow-slate-200">
                      <Calendar className="h-5 w-5" />
                      Schedule Visit
                   </button>
                </div>

                <div className="mt-8 pt-8 border-t border-gray-50 flex items-center justify-between">
                   <div className="flex -space-x-2">
                      {[1,2,3].map(i => (
                        <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-gray-200"></div>
                      ))}
                      <div className="w-8 h-8 rounded-full border-2 border-white bg-blue-50 flex items-center justify-center">
                         <span className="text-[10px] font-black text-blue-600">+12</span>
                      </div>
                   </div>
                   <p className="text-xs text-gray-400 font-bold">Interested recently</p>
                </div>
             </div>

             {/* Safety Tips */}
             <div className="bg-emerald-50 rounded-3xl p-6 flex gap-4">
                <Info className="h-6 w-6 text-emerald-600 shrink-0" />
                <div>
                   <p className="text-sm font-bold text-emerald-900 mb-1">Safety First</p>
                   <p className="text-xs text-emerald-700 leading-relaxed font-semibold">
                      Never send payments upfront for site visits. SmartProp AI verifies all agents, but we recommend visiting properties in day light.
                   </p>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}
