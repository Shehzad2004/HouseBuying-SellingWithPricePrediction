import React, { useState } from 'react';
import { Sparkles, TrendingUp, Info, MapPin, Square, BedDouble, Bath, ArrowRight, Loader2, CheckCircle2 } from 'lucide-react';
import { predictPropertyPrice } from '../services/geminiService';
import { motion, AnimatePresence } from 'motion/react';
import { Area, AreaChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts';

const mockTrendData = [
  { month: 'Jan', price: 21000000 },
  { month: 'Feb', price: 21500000 },
  { month: 'Mar', price: 21200000 },
  { month: 'Apr', price: 22000000 },
  { month: 'May', price: 23500000 },
  { month: 'Jun', price: 23000000 },
];

export default function AIPredictor() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [formData, setFormData] = useState({
    location: '',
    city: 'Islamabad',
    area: 5,
    areaUnit: 'marla',
    bedrooms: 3,
    bathrooms: 3,
    type: 'house'
  });

  const handlePredict = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const prediction = await predictPropertyPrice(formData as any);
      setResult(prediction);
    } catch (err) {
      console.error(err);
      // Fallback for demo
      setResult({
        estimatedPrice: 22500000,
        priceRange: { min: 21000000, max: 24000000 },
        confidenceScore: 0.85,
        marketInsights: "The market in this area is currently experiencing high demand for 5-marla modern houses. Prices have grown by 8% in the last quarter.",
        isOverpriced: false
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
        {/* Left Side: Form */}
        <div className="space-y-12">
          <div>
            <div className="inline-flex items-center space-x-2 bg-amber-50 text-amber-700 px-4 py-1.5 rounded-full text-[10px] font-black tracking-[0.2em] uppercase mb-8 shadow-sm">
              <Sparkles className="h-4 w-4" />
              <span>Future Forecasting</span>
            </div>
            <h1 className="text-6xl font-black text-slate-950 tracking-tight leading-[1.05] mb-6">
              Property Price <br/><span className="text-indigo-600">Forecasting.</span>
            </h1>
            <p className="text-slate-500 text-lg leading-relaxed max-w-md font-medium">
              Enter your property details below. Our AI model will analyze thousands of similar listings and market trends to give you an accurate valuation.
            </p>
          </div>

          <form onSubmit={handlePredict} className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-xl shadow-gray-100 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="col-span-full">
                <label className="block text-sm font-black text-gray-900 mb-2">Location / Sector</label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input 
                    type="text" 
                    placeholder="e.g. F-7, Gulberg 3, Phase 6"
                    className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border-none rounded-2xl text-sm focus:ring-2 focus:ring-purple-600 transition"
                    required
                    onChange={(e) => setFormData({...formData, location: e.target.value})}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-black text-gray-900 mb-2">Property Type</label>
                <select 
                  className="w-full px-4 py-3.5 bg-gray-50 border-none rounded-2xl text-sm focus:ring-2 focus:ring-purple-600"
                  onChange={(e) => setFormData({...formData, type: e.target.value})}
                >
                  <option value="house">House</option>
                  <option value="apartment">Apartment</option>
                  <option value="plot">Plot / Land</option>
                  <option value="commercial">Commercial</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-black text-gray-900 mb-2">City</label>
                <select 
                  className="w-full px-4 py-3.5 bg-gray-50 border-none rounded-2xl text-sm focus:ring-2 focus:ring-purple-600"
                  onChange={(e) => setFormData({...formData, city: e.target.value})}
                >
                  <option>Islamabad</option>
                  <option>Lahore</option>
                  <option>Rawalpindi</option>
                  <option>Karachi</option>
                  <option>Peshawar</option>
                  <option>Abbottabad</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-black text-gray-900 mb-2">Area Size</label>
                <div className="flex space-x-2">
                  <input 
                    type="number" 
                    className="w-full px-4 py-3.5 bg-gray-50 border-none rounded-2xl text-sm focus:ring-2 focus:ring-purple-600"
                    defaultValue={5}
                    onChange={(e) => setFormData({...formData, area: Number(e.target.value)})}
                  />
                  <select 
                    className="px-4 py-3.5 bg-gray-100 border-none rounded-2xl text-xs font-bold"
                    onChange={(e) => setFormData({...formData, areaUnit: e.target.value})}
                  >
                    <option value="marla">Marla</option>
                    <option value="kanal">Kanal</option>
                    <option value="sqft">Sqft</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-400 mb-2 uppercase tracking-widest">Beds</label>
                  <div className="flex items-center bg-gray-50 rounded-2xl px-2">
                    <BedDouble className="h-4 w-4 text-gray-400 ml-2" />
                    <input 
                      type="number" 
                      className="w-full px-2 py-3.5 bg-transparent border-none text-sm focus:ring-0" 
                      defaultValue={3}
                      onChange={(e) => setFormData({...formData, bedrooms: Number(e.target.value)})}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-400 mb-2 uppercase tracking-widest">Baths</label>
                  <div className="flex items-center bg-gray-50 rounded-2xl px-2">
                    <Bath className="h-4 w-4 text-gray-400 ml-2" />
                    <input 
                      type="number" 
                      className="w-full px-2 py-3.5 bg-transparent border-none text-sm focus:ring-0" 
                      defaultValue={3}
                      onChange={(e) => setFormData({...formData, bathrooms: Number(e.target.value)})}
                    />
                  </div>
                </div>
              </div>
            </div>

            <button 
              type="submit"
              disabled={loading}
              className="w-full py-5 bg-indigo-600 text-white rounded-[1.5rem] font-black text-xl uppercase tracking-widest hover:bg-indigo-700 transition shadow-2xl shadow-indigo-100 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-4"
            >
              {loading ? (
                <>
                  <Loader2 className="h-6 w-6 animate-spin" />
                  Generating Analysis...
                </>
              ) : (
                <>
                  Predict Value
                  <ArrowRight className="h-6 w-6" />
                </>
              )}
            </button>
          </form>
        </div>

        {/* Right Side: Prediction Result */}
        <div className="lg:sticky lg:top-32 h-full">
          <AnimatePresence mode="wait">
            {!result ? (
              <motion.div 
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="bg-gray-50 border-2 border-dashed border-gray-200 rounded-[2.5rem] p-12 flex flex-col items-center justify-center text-center h-[600px]"
              >
                <div className="bg-white p-8 rounded-full shadow-lg mb-8 relative">
                   <div className="absolute -top-2 -right-2 bg-purple-600 p-2 rounded-full ring-4 ring-white">
                      <Sparkles className="h-6 w-6 text-white" />
                   </div>
                   <TrendingUp className="h-16 w-16 text-purple-600" />
                </div>
                <h3 className="text-2xl font-black text-gray-900 mb-4">Awaiting Signal...</h3>
                <p className="text-gray-500 max-w-xs leading-relaxed font-medium">
                  Complete the form to see AI insights, valuation ranges, and market growth predictions for your property.
                </p>
              </motion.div>
            ) : (
              <motion.div 
                key="result"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-slate-950 rounded-[3rem] border border-white/10 shadow-2xl p-12 space-y-12 text-white"
              >
                <div className="flex items-center justify-between">
                   <div className="flex items-center space-x-3 text-emerald-400">
                      <CheckCircle2 className="h-7 w-7" />
                      <span className="text-xs font-black tracking-[0.2em] uppercase">Verified IQ Audit</span>
                   </div>
                   <div className="bg-amber-500 text-indigo-950 px-4 py-1.5 rounded-xl text-[10px] font-black uppercase">
                      Accuracy: {Math.round(result.confidenceScore * 100)}%
                   </div>
                </div>

                <div>
                   <p className="text-[10px] uppercase tracking-[0.3em] text-slate-400 font-black mb-4">Estimated Fair Value</p>
                   <div className="flex items-start gap-4 flex-col">
                      <h2 className="text-7xl font-black text-white leading-none">
                         {result.estimatedPrice >= 10000000 ? `${(result.estimatedPrice / 10000000).toFixed(2)}` : `${result.estimatedPrice.toLocaleString()}`}
                         <span className="text-2xl text-amber-500 ml-2">{result.estimatedPrice >= 10000000 ? 'Cr' : 'PKR'}</span>
                      </h2>
                      <span className={`px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${result.isOverpriced ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'}`}>
                         {result.isOverpriced ? 'Caution: High Price' : 'Excellent Investment'}
                      </span>
                   </div>
                   <p className="text-slate-400 font-bold mt-6 flex items-center gap-3">
                      <span className="w-2 h-2 bg-indigo-500 rounded-full"></span>
                      Fair Bracket: {result.priceRange.min.toLocaleString()} — {result.priceRange.max.toLocaleString()}
                   </p>
                </div>

                <div className="bg-gray-50 rounded-3xl p-6">
                   <h4 className="text-sm font-black text-gray-900 mb-4 flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-purple-600" />
                      Area Price Trend (6M)
                   </h4>
                   <div className="h-48 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={mockTrendData}>
                          <defs>
                            <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <Area type="monotone" dataKey="price" stroke="#8b5cf6" strokeWidth={3} fillOpacity={1} fill="url(#colorPrice)" />
                        </AreaChart>
                      </ResponsiveContainer>
                   </div>
                </div>

                <div className="flex gap-4">
                  <div className="bg-purple-600/5 p-5 rounded-2xl flex-grow">
                     <p className="text-xs font-black text-purple-900 uppercase tracking-widest mb-3">AI Market Insight</p>
                     <p className="text-gray-700 text-sm leading-loose italic">{result.marketInsights}</p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 pt-4 bg-transparent outline-none ring-0">
                   <button className="flex-grow py-4 bg-gray-900 text-white rounded-xl font-bold flex items-center justify-center gap-2">
                       Download Report PDF
                   </button>
                   <button className="flex-grow py-4 border-2 border-gray-100 text-gray-900 rounded-xl font-bold hover:border-purple-600 transition">
                       Save Prediction
                   </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
