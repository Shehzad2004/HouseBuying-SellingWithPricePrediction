import React, { useState } from 'react';
import { Mail, Lock, User, Sparkles, Home, ArrowRight, Loader2 } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { auth, db } from '../lib/firebase';
import { signInWithPopup, GoogleAuthProvider, createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { motion } from 'motion/react';
import { UserRole } from '../types';

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [role, setRole] = useState<UserRole>(UserRole.BUYER);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    setLoading(true);
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      const userRef = doc(db, 'users', user.uid);
      const userSnap = await getDoc(userRef);
      
      if (!userSnap.exists()) {
        await setDoc(userRef, {
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          photoURL: user.photoURL,
          role: role,
          isVerified: true,
          createdAt: new Date().toISOString()
        });
      }
      navigate('/');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-4 bg-transparent outline-none ring-0">
      <div className="max-w-6xl w-full grid grid-cols-1 md:grid-cols-2 gap-12 items-center bg-transparent">
        
        {/* Left Side: Branding */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="hidden md:block"
        >
          <div className="bg-indigo-600 w-20 h-20 rounded-[2rem] flex items-center justify-center mb-10 shadow-2xl shadow-indigo-200">
             <Home className="h-10 w-10 text-white" />
          </div>
          <h2 className="text-7xl font-black text-slate-950 leading-[1.05] tracking-tight mb-8">
            The Smart Way <br/><span className="text-indigo-600">to Property.</span>
          </h2>
          <p className="text-xl text-slate-500 max-w-sm leading-relaxed font-medium">
            Create an account to save properties, get AI price alerts, and chat directly with sellers.
          </p>
          
          <div className="mt-12 space-y-8">
            {[
              { icon: Sparkles, text: 'Personalized AI Recommendations', color: 'text-amber-500', bg: 'bg-amber-50' },
              { icon: ArrowRight, text: 'Instant Direct Messaging', color: 'text-indigo-600', bg: 'bg-indigo-50' },
              { icon: ArrowRight, text: 'Manage Multi-City Listings', color: 'text-indigo-600', bg: 'bg-indigo-50' },
            ].map((item, i) => (
              <div key={i} className="flex items-center space-x-5">
                <div className={`p-3 ${item.bg} rounded-2xl`}>
                  <item.icon className={`h-6 w-6 ${item.color}`} />
                </div>
                <span className="font-black text-slate-700 tracking-tight">{item.text}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Right Side: Form */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-12 rounded-[3.5rem] border border-slate-100 shadow-[0_32px_64px_-15px_rgba(0,0,0,0.1)]"
        >
          <div className="text-center mb-12">
            <h3 className="text-4xl font-black text-slate-950 tracking-tight mb-4">{isLogin ? 'Hello Again' : 'Join the Future'}</h3>
            <p className="text-slate-500 font-medium">Professional grade real estate tools await you.</p>
          </div>

          <div className="space-y-8">
            <button 
              onClick={handleGoogleLogin}
              disabled={loading}
              className="w-full py-5 border-2 border-slate-100 rounded-2xl flex items-center justify-center space-x-4 font-black uppercase tracking-widest text-xs text-slate-700 hover:border-indigo-600 hover:bg-slate-50 transition disabled:opacity-50"
            >
              <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="h-6 w-6" alt="Google" />
              <span>Continue with Google</span>
            </button>

            <div className="relative py-2">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-100"></div>
              </div>
              <div className="relative flex justify-center text-[10px] uppercase tracking-[0.3em] font-black text-slate-400 bg-white px-6">
                Direct Sync
              </div>
            </div>

            {!isLogin && (
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">I am a...</label>
                <div className="grid grid-cols-2 gap-3">
                   {[UserRole.BUYER, UserRole.SELLER, UserRole.AGENT].map((r) => (
                     <button
                        key={r}
                        onClick={() => setRole(r)}
                        className={`py-3 rounded-xl border-2 text-sm font-bold transition ${role === r ? 'border-blue-600 bg-blue-50 text-blue-700' : 'border-gray-50 bg-gray-50 text-gray-500'}`}
                      >
                        {r.charAt(0).toUpperCase() + r.slice(1)}
                     </button>
                   ))}
                </div>
              </div>
            )}

            <div className="space-y-4">
               <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input type="email" placeholder="Email Address" className="w-full pl-12 pr-4 py-4 bg-gray-50 border-none rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 transition" />
               </div>
               <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input type="password" placeholder="Password" className="w-full pl-12 pr-4 py-4 bg-gray-50 border-none rounded-2xl text-sm focus:ring-2 focus:ring-blue-600 transition" />
               </div>
            </div>

            {error && <p className="text-red-500 text-xs font-bold text-center">{error}</p>}

            <button 
              className="w-full py-4 bg-blue-600 text-white rounded-2xl font-black text-lg hover:bg-blue-700 transition shadow-xl shadow-blue-100 flex items-center justify-center gap-2"
              disabled={loading}
              onClick={() => setError('Email auth is ready for implementation. Please use Google Login for now.')}
            >
              {loading ? <Loader2 className="h-6 w-6 animate-spin" /> : (isLogin ? 'Sign In' : 'Get Started')}
            </button>

            <p className="text-center text-sm font-medium text-gray-500">
              {isLogin ? "Don't have an account? " : "Already have an account? "}
              <button 
                onClick={() => setIsLogin(!isLogin)}
                className="text-blue-600 font-bold hover:underline"
              >
                {isLogin ? 'Create one' : 'Log in instead'}
              </button>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
