import React, { useState, useEffect } from 'react';
import { 
  Home, Search, PlusCircle, MessageSquare, Heart, 
  User, LayoutDashboard, Calculator, Menu, X, LogOut,
  Sparkles, TrendingUp, Info
} from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { auth } from '../lib/firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

import FloatingChatbot from './FloatingChatbot';

export default function Layout({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState(auth.currentUser);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    return onAuthStateChanged(auth, (u) => setUser(u));
  }, []);

  const navigation = [
    { name: 'Home', href: '/', icon: Home },
    { name: 'Discover', href: '/search', icon: Search },
    { name: 'AI Predictor', href: '/predict', icon: Sparkles },
    { name: 'Mortgage', href: '/calculator', icon: Calculator },
  ];

  const authNavigation = [
    { name: 'My Listings', href: '/my-properties', icon: LayoutDashboard },
    { name: 'Messages', href: '/messages', icon: MessageSquare },
    { name: 'Saved', href: '/saved', icon: Heart },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans">
      {/* Navbar ... */}
      {/* (Rest of existing navbar logic stays same) */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link to="/" className="flex items-center space-x-2">
                <div className="bg-indigo-600 p-2 rounded-lg">
                  <Home className="h-6 w-6 text-white" />
                </div>
                <span className="text-xl font-bold text-slate-900 tracking-tight">SmartProp AI</span>
              </Link>
              <div className="hidden md:ml-8 md:flex md:space-x-4">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    to={item.href}
                    className={cn(
                      "px-3 py-2 rounded-md text-sm font-medium transition-colors",
                      location.pathname === item.href
                        ? "bg-indigo-50 text-indigo-700"
                        : "text-slate-500 hover:text-slate-900 hover:bg-slate-100"
                    )}
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
            </div>

            <div className="hidden md:flex items-center space-x-4">
              {user ? (
                <>
                  <Link to="/list-property" className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition flex items-center gap-2">
                    <PlusCircle className="h-4 w-4" />
                    List Property
                  </Link>
                  <div className="flex items-center space-x-2 pl-4 border-l border-slate-200">
                    {authNavigation.map((item) => (
                      <Link
                        key={item.name}
                        to={item.href}
                        title={item.name}
                        className={cn(
                          "p-2 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition",
                          location.pathname === item.href && "text-indigo-600 bg-indigo-50"
                        )}
                      >
                        <item.icon className="h-5 w-5" />
                      </Link>
                    ))}
                    <button 
                      onClick={() => signOut(auth)}
                      className="p-2 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition"
                    >
                      <LogOut className="h-5 w-5" />
                    </button>
                  </div>
                </>
              ) : (
                <Link to="/login" className="bg-slate-100 text-slate-900 px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-200 transition">
                  Sign In
                </Link>
              )}
            </div>

            <div className="flex md:hidden items-center">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-t border-gray-200 overflow-hidden"
            >
              <div className="px-2 pt-2 pb-3 space-y-1">
                {[...navigation, ...(user ? authNavigation : [])].map((item) => (
                  <Link
                    key={item.name}
                    to={item.href}
                    onClick={() => setIsMenuOpen(false)}
                    className={cn(
                      "block px-3 py-2 rounded-md text-base font-medium flex items-center space-x-3",
                      location.pathname === item.href
                        ? "bg-blue-50 text-blue-700"
                        : "text-gray-500 hover:text-gray-900 hover:bg-gray-100"
                    )}
                  >
                    <item.icon className="h-5 w-5" />
                    <span>{item.name}</span>
                  </Link>
                ))}
              </div>
              <div className="pt-4 pb-3 border-t border-gray-200 px-5">
                {user ? (
                  <button
                    onClick={() => signOut(auth)}
                    className="w-full flex items-center space-x-3 text-red-500 font-medium py-2"
                  >
                    <LogOut className="h-5 w-5" />
                    <span>Sign Out</span>
                  </button>
                ) : (
                  <Link
                    to="/login"
                    onClick={() => setIsMenuOpen(false)}
                    className="block w-full text-center bg-blue-600 text-white px-4 py-2 rounded-lg font-medium"
                  >
                    Sign In
                  </Link>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      <main className="flex-grow">
        {children}
      </main>

      <FloatingChatbot />

      <footer className="bg-indigo-950 text-white py-16 px-4 shadow-sm">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-6">
              <div className="bg-amber-500 p-1.5 rounded-lg">
                <Home className="h-5 w-5 text-indigo-950" />
              </div>
              <span className="text-xl font-bold text-white">SmartProp AI</span>
            </div>
            <p className="text-indigo-200 max-w-sm mb-4">
              The next generation real-estate platform with built-in AI for accurate valuations, market insights, and predictive analytics.
            </p>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-6 uppercase tracking-widest text-xs">Platform</h4>
            <ul className="space-y-3 text-indigo-300 text-sm">
              <li className="hover:text-amber-400 transition-colors cursor-pointer">Listing Search</li>
              <li className="hover:text-amber-400 transition-colors cursor-pointer">Price Predictor</li>
              <li className="hover:text-amber-400 transition-colors cursor-pointer">Agent Directory</li>
              <li className="hover:text-amber-400 transition-colors cursor-pointer">News & Trends</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-6 uppercase tracking-widest text-xs">Support</h4>
            <ul className="space-y-3 text-indigo-300 text-sm">
              <li className="hover:text-amber-400 transition-colors cursor-pointer">Help Center</li>
              <li className="hover:text-amber-400 transition-colors cursor-pointer">Legal Status Info</li>
              <li className="hover:text-amber-400 transition-colors cursor-pointer">Mortgage Guide</li>
              <li className="hover:text-amber-400 transition-colors cursor-pointer">Contact Us</li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-indigo-900 flex flex-col md:flex-row justify-between items-center bg-transparent">
          <p className="text-sm text-indigo-400">&copy; 2025 SmartProp AI. Built for FYP COMSATS Abbottabad.</p>
          <div className="flex space-x-6 mt-6 md:mt-0">
             <span className="text-[10px] text-amber-500 font-black uppercase tracking-widest">Innovation · Trust · Efficiency</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
