import React from 'react';
import { MapPin, BedDouble, Bath, Square, Sparkles, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Property } from '../types';
import { motion } from 'motion/react';

interface PropertyCardProps {
  property: Property;
  isSaved?: boolean;
}

export default function PropertyCard({ property, isSaved = false }: PropertyCardProps) {
  return (
    <motion.div 
      whileHover={{ y: -4 }}
      className="bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 group"
    >
      <div className="relative aspect-[4/3]">
        <img 
          src={property.images[0] || 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&q=80&w=600'} 
          alt={property.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-4 left-4 flex gap-2">
          {property.listingType === 'sell' ? (
            <span className="bg-indigo-600 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-wider shadow-lg shadow-indigo-200">For Sale</span>
          ) : (
            <span className="bg-emerald-600 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-wider shadow-lg shadow-emerald-200">For Rent</span>
          )}
          {property.isAIPredicted && (
            <span className="bg-amber-500 text-indigo-950 text-[10px] font-black px-3 py-1 rounded-full flex items-center gap-1 shadow-lg shadow-amber-200">
              <Sparkles className="h-3 w-3" />
              AI Valued
            </span>
          )}
        </div>
        <button className="absolute top-4 right-4 p-2 bg-white/80 backdrop-blur-md rounded-full shadow-sm hover:bg-white transition-colors">
          <Heart className={`h-5 w-5 ${isSaved ? 'fill-red-500 text-red-500' : 'text-gray-600'}`} />
        </button>
      </div>

      <div className="p-5">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-gray-900 line-clamp-1">{property.title}</h3>
        </div>
        
        <div className="flex items-center text-gray-500 text-sm mb-4">
          <MapPin className="h-4 w-4 mr-1 shrink-0" />
          <span className="line-clamp-1">{property.location}, {property.city}</span>
        </div>

        <div className="flex justify-between items-center mb-6 pt-4 border-t border-gray-50">
          <div className="flex space-x-4">
            <div className="flex items-center text-gray-700">
              <BedDouble className="h-4 w-4 mr-1.5 text-gray-400" />
              <span className="text-sm font-semibold">{property.bedrooms}</span>
            </div>
            <div className="flex items-center text-gray-700">
              <Bath className="h-4 w-4 mr-1.5 text-gray-400" />
              <span className="text-sm font-semibold">{property.bathrooms}</span>
            </div>
            <div className="flex items-center text-gray-700">
              <Square className="h-4 w-4 mr-1.5 text-gray-400" />
              <span className="text-sm font-semibold">{property.area} <span className="text-[10px] text-gray-400 font-normal uppercase">{property.areaUnit}</span></span>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <p className="text-[9px] uppercase tracking-[0.2em] text-slate-400 font-black mb-1">Estimated Value</p>
            <p className="text-2xl font-black text-indigo-700">
              Rs. {property.price.toLocaleString()}
            </p>
          </div>
          <Link 
            to={`/property/${property.id}`}
            className="inline-flex items-center justify-center h-10 px-5 bg-slate-900 text-white text-xs font-black uppercase tracking-widest rounded-xl hover:bg-indigo-600 transition shadow-lg"
          >
            Details
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
