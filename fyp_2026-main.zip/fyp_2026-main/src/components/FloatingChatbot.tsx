import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Sparkles, Loader2, Bot } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { chatWithAssistant } from '../services/geminiService';
import Markdown from 'react-markdown';
import { cn } from '../lib/utils';

export default function FloatingChatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'model'; text: string }[]>([
    { role: 'model', text: 'Hi! I am your SmartProp AI assistant. How can I help you with your property journey today?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));
      const response = await chatWithAssistant(userMsg, history);
      setMessages(prev => [...prev, { role: 'model', text: response }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'model', text: "Sorry, I encountered an error. Please try again later." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[100] bg-transparent outline-none ring-0">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="mb-4 w-[400px] h-[550px] bg-white rounded-[3rem] shadow-[0_32px_64px_-15px_rgba(0,0,0,0.15)] border border-slate-100 flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="bg-slate-950 p-8 flex items-center justify-between">
              <div className="flex items-center gap-4">
                 <div className="bg-amber-500 p-2.5 rounded-[1rem] shadow-lg shadow-amber-500/20">
                    <Bot className="h-6 w-6 text-indigo-950" />
                 </div>
                 <div>
                    <h3 className="text-white font-black text-sm tracking-tight">SmartProp AI</h3>
                    <p className="text-[10px] text-indigo-400 font-black uppercase tracking-[0.2em]">Active Neural Link</p>
                 </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Content */}
            <div ref={scrollRef} className="flex-grow overflow-y-auto p-8 space-y-8 bg-slate-50/50">
               {messages.map((m, i) => (
                 <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={cn(
                      "max-w-[85%] p-6 text-sm font-medium leading-relaxed shadow-sm",
                      m.role === 'user' 
                        ? 'bg-indigo-600 text-white rounded-[2rem] rounded-tr-none shadow-xl shadow-indigo-100' 
                        : 'bg-white text-slate-800 rounded-[2rem] rounded-tl-none border border-slate-100'
                    )}>
                       <Markdown>{m.text}</Markdown>
                    </div>
                 </div>
               ))}
               {loading && (
                 <div className="flex justify-start">
                    <div className="bg-white p-6 rounded-[2rem] rounded-tl-none border border-slate-100 flex items-center gap-3 shadow-sm">
                       <Loader2 className="h-4 w-4 animate-spin text-indigo-600" />
                       <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Neural Thinking...</span>
                    </div>
                 </div>
               )}
            </div>

            {/* Input */}
            <form onSubmit={handleSend} className="p-8 border-t border-slate-50 bg-white">
               <div className="relative group">
                  <input 
                    type="text" 
                    placeholder="Ask our AI about specific sectors..."
                    className="w-full pl-8 pr-16 py-5 bg-slate-50 border-2 border-transparent focus:bg-white focus:border-indigo-600 rounded-[1.5rem] text-sm font-semibold transition-all shadow-inner"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                  />
                  <button 
                    type="submit"
                    className="absolute right-2 top-1/2 -translate-y-1/2 w-12 h-12 bg-indigo-600 text-white rounded-2xl shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition flex items-center justify-center"
                  >
                    <Send className="h-5 w-5" />
                  </button>
               </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-20 h-20 bg-indigo-600 text-white rounded-[2rem] shadow-[0_24px_48px_-10px_rgba(79,70,229,0.3)] flex items-center justify-center hover:scale-105 active:scale-95 transition-all relative overflow-hidden group border-2 border-white/20"
      >
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-white/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
        {isOpen ? <X className="h-8 w-8" /> : <MessageSquare className="h-8 w-8" />}
        <div className="absolute -top-1 -right-1">
           <Sparkles className="h-6 w-6 text-amber-400 fill-amber-400 animate-pulse" />
        </div>
      </button>
    </div>
  );
}
