import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import SearchPage from './pages/Search';
import AIPredictor from './pages/AIPredictor';
import MortgageCalculator from './pages/Calculator';
import AuthPage from './pages/Auth';

import PropertyDetail from './pages/PropertyDetail';
import ManageProperties from './pages/ManageProperties';
import Messaging from './pages/Messages';

export default function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/property/:id" element={<PropertyDetail />} />
          <Route path="/predict" element={<AIPredictor />} />
          <Route path="/calculator" element={<MortgageCalculator />} />
          <Route path="/my-properties" element={<ManageProperties />} />
          <Route path="/messages" element={<Messaging />} />
          <Route path="/login" element={<AuthPage />} />
          {/* Fallback for other modules as placeholders */}
          <Route path="*" element={<Home />} />
        </Routes>
      </Layout>
    </Router>
  );
}
