export enum UserRole {
  BUYER = 'buyer',
  SELLER = 'seller',
  AGENT = 'agent',
  ADMIN = 'admin',
}

export enum PropertyType {
  HOUSE = 'house',
  APARTMENT = 'apartment',
  PLOT = 'plot',
  COMMERCIAL = 'commercial',
}

export enum ListingType {
  SELL = 'sell',
  RENT = 'rent',
}

export enum PropertyStatus {
  ACTIVE = 'active',
  SOLD = 'sold',
  RENTED = 'rented',
  PENDING = 'pending',
}

export interface User {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: UserRole;
  phoneNumber?: string;
  isVerified: boolean;
  createdAt: string;
}

export interface Property {
  id: string;
  title: string;
  description: string;
  price: number;
  location: string;
  city: string;
  type: PropertyType;
  bedrooms: number;
  bathrooms: number;
  area: number;
  areaUnit: 'marla' | 'kanal' | 'sqft';
  images: string[];
  ownerId: string;
  agentId?: string;
  status: PropertyStatus;
  listingType: ListingType;
  isAIPredicted?: boolean;
  aiEstimatedPrice?: number;
  aiConfidenceScore?: number;
  createdAt: string;
  updatedAt: string;
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  createdAt: string;
}

export interface Inquiry {
  id: string;
  propertyId: string;
  senderId: string;
  receiverId: string;
  message: string;
  status: 'new' | 'replied' | 'closed';
  createdAt: string;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}
