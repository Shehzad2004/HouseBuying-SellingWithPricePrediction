import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export async function predictPropertyPrice(details: {
  location: string;
  area: number;
  areaUnit: string;
  bedrooms: number;
  bathrooms: number;
  type: string;
}) {
  if (!ai) throw new Error("GEMINI_API_KEY is not configured");

  const prompt = `
    As a real estate expert in Pakistan, predict the fair market price range for a property with these details:
    - Location: ${details.location}
    - Area: ${details.area} ${details.areaUnit}
    - Type: ${details.type}
    - Bedrooms: ${details.bedrooms}
    - Bathrooms: ${details.bathrooms}

    Provide your response in JSON format:
    {
      "estimatedPrice": number,
      "priceRange": { "min": number, "max": number },
      "confidenceScore": number (0-1),
      "marketInsights": "string",
      "isOverpriced": boolean (relative to a mock listing price)
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const text = response.text.replace(/```json|```/g, "").trim();
    return JSON.parse(text);
  } catch (error) {
    console.error("AI Price Prediction Error:", error);
    throw error;
  }
}

export async function chatWithAssistant(message: string, history: any[]) {
  if (!ai) throw new Error("GEMINI_API_KEY is not configured");

  // In the new SDK, chat is handled differently. For simplicity and following the skill's flow:
  // We'll use generateContent with the full history as contents.

  const contents = history.map(item => ({
    role: item.role,
    parts: item.parts
  }));

  // Add the new message
  contents.push({
    role: 'user',
    parts: [{ text: message }]
  });

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: contents,
      config: {
        systemInstruction: "You are SmartProp AI, an expert real estate assistant specializing in the Pakistani market. Provide helpful, data-driven advice on buying, selling, and renting properties."
      }
    });

    return response.text;
  } catch (error) {
    console.error("Chat Assistant Error:", error);
    throw error;
  }
}
